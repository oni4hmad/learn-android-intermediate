# Shared Elements in Android Navigation Architecture Component

https://medium.com/@serbelga/shared-elements-in-android-navigation-architecture-component-bc5e7922ecdf

<img src="./screenshots/sample.gif?sanitize=true" width="480">
